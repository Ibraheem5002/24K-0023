#include <stdio.h>
    int main ()
{
    int Num;
    int Sum = 0;

    while (Num != 0)
    {
        printf("input your desired number: ");
        scanf("%d", &Num);
        
        Sum = Sum + Num;
    }
    
    printf("your total sum: %d", Sum);

    return 0;

}