#include <stdio.h>
    int main ()
{
    int Max = -99999;
    int Min = 99999;
    int size;

    printf("input the size of your array: ");
    scanf("%d", &size);

    int Array[size];

    printf("input your data [integers only]: \n");
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &Array[i]);
    }

    for (int i = 0; i < size; i++)
    {
        if (Array[i] > Max)
        {
            Max = Array[i];
        }
        if (Array[i] < Min)
        {
            Min = Array[i];
        }
    }
    
    printf("max number: %d\n", Max);
    printf("min number: %d", Min);
    
    return 0;
}