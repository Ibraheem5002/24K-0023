#include <stdio.h>
    int main()
{ // start main

    int N;

    printf("input a +ve interger [between 1 and 9] \n");
    scanf("%d", &N);

    if(N >= 1 && N <= 9)
    { // start if

        switch (N)
        { // start switch
        case 1:

            printf("one");

            break;

         case 2:

            printf("two");

            break;

         case 3:

            printf("three");

            break;

        case 4:

            printf("four");

            break;

        case 5:

            printf("five");

            break;

        case 6:

            printf("six");

            break;

        case 7:

            printf("seven");

            break;

        case 8:

            printf("eight");

            break;

        default:

            printf("nine");

            break;

        } // end switch

    } // end if

    else if (N > 9)
    { // start else if

        printf("greater then 9");

    } // end else if
    
    else
    { // start else

        printf("invalid input");

    } // end if 

    return 0;

} // end main