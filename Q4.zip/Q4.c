#include <stdio.h>
	int main ()
{
	char Op;
	int L1;
	int L2;
	float Area;
	printf("input your choice for calculating the area of that shape [C for Circle, R for rectangle, T for triagngle] \n");
	scanf("%c", &Op);
	switch (Op)
	{
		case 'C':
			printf("input your radius: \n");
			scanf("%d", &L1);
			Area = 3.14159265*L1;
			printf("your area is: %f \n", Area);
			break;
			
		case 'R':
			printf("input your length: \n");
			scanf("%d", &L1);
			printf("input your width: \n");
			scanf("%d", &L2);
			Area = L1 * L2;
			printf("your area is: %f \n", Area);
			break;
			
		case 'T':
			printf("input your length: \n");
			scanf("%d", &L1);
			printf("input your height: \n");
			scanf("%d", &L2);
			Area = L1 * L2 * 0.5;
			printf("your area is: %f \n", Area);
			break;
			
		default:
			printf("invalid input");
			break;	
		return 0;
	}
}