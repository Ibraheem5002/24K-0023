#include<stdio.h>
	int main()
{

// declaring the variables

	float Tax_Rate;
	float Salary;
	float Tax;
	float Remain;

// inputing the data

	printf("enter your tax rate:");
	scanf("%f", &Tax_Rate);
	printf("enter you salary:");
	scanf("%f", &Salary);

// processing

	Tax = (Salary * Tax_Rate) / 100;
	Remain = Salary - Tax;

// printing the result

	printf("your tax is: %f\n", Tax);
	printf("your remaining salary is: %f\n", Remain);

return 0;

}