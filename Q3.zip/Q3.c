#include <stdio.h>
    int main()
{ // start main

    char Num;

    printf("input a single character [a letter should be in capital]: ");
    scanf("%c", &Num);

    if (Num == 'A' || Num == 'E' || Num == 'I' || Num == 'O' || Num == 'U')
    { // start if

        printf("you entered a vowel");

    } // end if

    else
        if (Num == 'B' || Num == 'C' || Num == 'D' || Num == 'F' || Num == 'G' || Num == 'H' || Num == 'J' || Num == 'K' || Num == 'L' || Num == 'M' || Num == 'N' || Num == 'P' || Num == 'Q' || Num == 'R' || Num == 'S' || Num == 'T' || Num == 'V' || Num == 'W' || Num == 'X' || Num == 'Y' || Num == 'Z')
        { // start else if

            printf("you hace entered a consonants");

        } // end else if

    else
        if (Num == '1' || Num == '2' || Num == '3' || Num == '4' || Num == '5' || Num == '6' || Num == '7' || Num == '8' || Num == '9' || Num == '0')
        { // start else if

            printf("you have entered a digit");

        } // end else if

    else
        { // start else

        printf(" you have entered a special character");

        } // end else

    return 0;

} // end main