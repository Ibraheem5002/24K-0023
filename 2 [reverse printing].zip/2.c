#include <stdio.h>
    int main ()
{
    int size;
    printf("input your size for the array");
    scanf("%d", &size);

    int array[size];

    printf("input your data [+ve integers] \n");
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &array[i]);
    }
    
    size = size - 1;
    printf("your data in reverse order \n");
    for (int i = size; i >= 0; i--)
    {
        printf("%d \n", array[i]);
    }
    return 0;
}