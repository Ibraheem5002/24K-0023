#include <stdio.h>
    int main ()
{
    int Num;
    int Prime = 0;
    int i = 0;
    int Div = 2;
    int T1 = 0;
    int T2 = 1;
    int T3 = 1;

    printf("input your number: ");
    scanf("%d", &Num);

    while (Div < Num)
    {
        if (Num % Div == 0)
        {
            Prime = Prime + 1;
        }
        Div = Div + 1;    
    }
    
    if (Prime == 0)
    {
        printf("%d", Num);
        printf("is a prime");
    }
    else
    {
        printf("%d", Num);
        printf("is a not a prime");
    }

    i = 1;

    printf("Fibonacci series: \n");
    printf("%d \n", T1);
    printf("%d \n", T2);

    while (i <= Num)
    {
        T1 = T2;
        T2 = T3;
        T3 = T1 + T2;
        printf("%d \n", T3);
        i = i + 1;

    }
    

    return 0;
}