#include <stdio.h>
    int main ()
{
    int PIN;
    int i = 2;
    int IN = 0;
    int State;

    // taking PIN input

    printf("enter your 4-digit PIN code: ");
    scanf("%d", &PIN);

    // PIN checking

    while (IN == 0 && i <= 3)
    {
        
        if (PIN == 5678)
        {
            IN = 1;
            i=4;
        }
        else 
        {
            printf("incorrect PIN. invalid input: ");
            scanf("%d", &PIN);
            i++;
        }

    }

    // taking out the card
    printf("Press 1 for your card back. Press 0 for exit: ");
    scanf("%d", &State);

    while (State != 0)
    {

        if (State == 1 && IN == 1)
        {
            printf("here is your card. the program will now exit \n");
            State = 0;
        }
        else if (State == 1 && IN == 0)
        {
            printf("You have input your PIN invalid 3 times. Your card is not blocked. the program will now exit \n");
            State = 0;
        }
        else
        {
            printf("invalid input \n");
        }

        
    }
    
    printf("thankyou for using our sevices");

    return 0;
}