#include <stdio.h>
    int main ()
{
    int Year;

    printf("input your desired year: ");
    scanf("%d", &Year);

    if (Year % 400 == 0)
    {
        printf("%d", Year); printf(" is a leap year"); 
    } // end if

    else if (Year % 4 == 0 && Year % 100 != 0)
    {
        printf("%d", Year); printf(" is a leap year");
    } // end else if

    else
    { printf("%d", Year); printf(" is a not leap year"); }

    return 0;

} // emd main