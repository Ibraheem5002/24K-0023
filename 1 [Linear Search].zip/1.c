#include <stdio.h>
    int main ()
{
    int ID[5] = {123, 456, 789, 147, 258};
    int Search; int Found = 0; int i = 0;

    printf("enter your search option: ");
    scanf("%d", &Search);

    while (i < 5)
    {
        if (Search == ID[i])
        {
            printf("your id is present at position: %d", i);
            Found = 1;
            break;
        }
        i=i+1;
    }
    if (Found == 0)
    {
        printf("your id is not present in the data base");
    }
    return 0;
}