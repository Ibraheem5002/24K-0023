#include <stdio.h>
    int main ()
{
    int Attendance;
    int Assignment;
    int Exam;
    int Result;

    printf("input your attendance percentage of this semester: ");
    scanf("%d", &Attendance);
    printf("input your assignments results [out of 50]: ");
    scanf("%d", &Assignment);
    printf("input your exam score [out of 50]: ");
    scanf("%d", &Exam);

    if (Attendance < 70)
    {
        printf("you have failed this course");
    } // end if

    else
    {
        Result = Assignment + Exam;
        if (Result < 50)
        {
            printf("you have failed this course. Your Result is: %d", Result);
        } // end if
        else
        {
            printf("you have passed this course. Your Result is: %d", Result);
        } // end if
    } // end else

    return 0;

} // end main  