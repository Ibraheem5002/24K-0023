#include <stdio.h>
    int main()
{ // start main

    char Op;
    float Num1;
    float Num2;
    float Ans;

    printf("input your desired operator [+, - , *, /] \n");
    scanf("%c", &Op);

    switch (Op)
    { // start switch
    case '+':

        printf("enter your first number: ");
        scanf("%f", &Num1);
        printf("enter your second number: ");
        scanf("%f", &Num2);

        Ans = Num1 + Num2;

        printf("Ans:  %f", Ans);
        break;

    case '-':

        printf("enter your first number: ");
        scanf("%f", &Num1);
        printf("enter your second number: ");
        scanf("%f", &Num2);

        Ans = Num1 - Num2;

        printf("Ans:  %f", Ans);
        break;

    case '*':

        printf("enter your first number: ");
        scanf("%f", &Num1);
        printf("enter your second number: ");
        scanf("%f", &Num2);

        Ans = Num1 * Num2;

        printf("Ans:  %f", Ans);
        break;

    case '/':

        printf("enter your first number: ");
        scanf("%f", &Num1);
        printf("enter your second number: ");
        scanf("%f", &Num2);

        Ans = Num1 / Num2;

        printf("Ans:  %f", Ans);
        break;

    default:

			printf("invalid input");
			break;

		return 0;
	} // end switch
} // end main