#include<stdio.h>
	int main()
{

// declaring the variables

	int Num1;
	int Num2;
	int Xtra;

// inputing the numbers
	printf("Enter num 1:");
	scanf("%d", &Num1);
	printf("Enter num 2:");
	scanf("%d", &Num2);

// the process
	Xtra = Num1;
	Num1 = Num2;
	Num2 = Xtra;

//printing the result
	printf("your new first number is: %d\n", Num1);
	printf("your new second number is: %d\n", Num2);

	return 0;
}