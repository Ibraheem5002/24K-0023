#include <stdio.h>
    int main ()
{
    int Start;
    int End;
    int Sum = 0;

   printf("enter your starting point: ");
   scanf("%d", &Start);
   printf("enter your ending point [ending point must be lower than starting point]: ");
   scanf("%d", &End);

   while (Start <= End)
   {
    if (Start % 2 == 0)
    {
        Sum = Sum + Start;
    }
    Start++;
   }
   
   printf("your total sum: %d", Sum);

   return 0;

}