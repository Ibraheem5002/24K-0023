#include <stdio.h>
    int main ()
{
    int PIN;
    int Encrypted;
    int Key;
    
    printf("enter your PIN code: \n");
    scanf("%d", &PIN);
    printf("enter your key [interger only]: \n");
    scanf("%d", &Key);

    Encrypted = PIN << Key;

    printf("your new encrypted PIN code: %d\n", Encrypted);
    printf("your key: %d\n", Key);

    return 0;

}