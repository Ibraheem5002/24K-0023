#include <stdio.h>
    int main()
{ // start main

    float Actual;
    float Discounted;
    float Saved;

    printf("input you actual amount: ");
    scanf("%f", &Actual);

    if(Actual >= 500 && Actual < 2000)
    { // start if

        Discounted = Actual * 0.95;
        Saved = Actual - Discounted;

        printf("You recieved 5 PERCENT discount");
        printf("\n");
        printf("Your acutal price is: %f", Actual);
        printf("\n");
        printf("Your discounted price is: %f", Discounted);
        printf("\n");
        printf("You saved: %f", Saved);

    } // end if

    else if (Actual >= 2000 && Actual < 4000)
    { // start else

        Discounted = Actual * 0.90;
        Saved = Actual - Discounted;

        printf("You recieved 10 PERCENT discount");
        printf("\n");
        printf("Your acutal price is: %f", Actual);
        printf("\n");
        printf("Your discounted price is: %f", Discounted);
        printf("\n");
        printf("You saved: %f", Saved);

    } // end else

    else if (Actual >= 4000 && Actual < 6000)
    { // start else

        Discounted = Actual * 0.80;
        Saved = Actual - Discounted;

        printf("You recieved 20 PERCENT discount");
        printf("\n");
        printf("Your acutal price is: %f", Actual);
        printf("\n");
        printf("Your discounted price is: %f", Discounted);
        printf("\n");
        printf("You saved: %f", Saved);

    } // end else

    else if (Actual >= 6000)
    { // start else

        Discounted = Actual * 0.65;
        Saved = Actual - Discounted;

        printf("You recieved 35 PERCENT discount");
        printf("\n");
        printf("Your acutal price is: %f", Actual);
        printf("\n");
        printf("Your discounted price is: %f", Discounted);
        printf("\n");
        printf("You saved: %f", Saved);

    } // end else

    else 
    { // start else 

        printf("invalid input");

    } // end else

    return 0;

} // end main