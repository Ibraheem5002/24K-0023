#include<stdio.h>
    int main()
{

    // declaring the variables

    float X1;
    float Y1;
    float X2;
    float Y2;
    float Gradient;

    // inputing the data

    printf("input your X1: \n");
    scanf("%f", &X1);
    printf("input your Y1: \n");
    scanf("%f", &Y1);
    printf("input your X2: \n");
    scanf("%f", &X2);
    printf("input your Y2: \n");
    scanf("%f", &Y2);

    // processing

    Gradient = (Y1 - Y2) / (X1 - X2);

    // outputing the results

    printf("the gradient is: %f\n", Gradient);

    return 0;

}