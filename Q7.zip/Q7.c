#include <stdio.h>
    int main()
{ // start main

    int ID;
    int Units;
    int Amount;
    int Surcharge;
    int Net;
    char N [1000];

    printf("input yout id: ");
    scanf("%d", &ID);
    printf("input your name: ");
    scanf("%s", &N);
    printf("input your units: ");
    scanf("%d", &Units);

    if(Units >= 199 && Units < 200)
    { // start if

        Amount = Units * 16.2;

        if(Amount > 18000)
        { // start if

            Surcharge = Amount * 0.15;

        } // end if

        else
        { // start if 

            Surcharge = 0;

        }// end else

        Net = Amount + Surcharge;

        printf(".");
        printf("Customer ID: %d", ID);
        printf("\n");
        printf("Customer Name: %s", N);
        printf("\n");
        printf("Units Consumed: %d", Units);
        printf("\n");
        printf("Amount Charges @ Rs16.20 per unit: %d", Amount);
        printf("\n");
        printf("Surcharge Amount: %d", Surcharge);
        printf("\n");
        printf("Net Amount Paid by the Customer: %d", Net);

    } // end if

    else if(Units >= 200 && Units < 300)
    { // start if

        Amount = Units * 20.1;

        if(Amount > 18000)
        { // start if

            Surcharge = Amount * 0.15;

        } // end if

        else
        { // start if 

            Surcharge = 0;

        }// end else

        Net = Amount + Surcharge;

        printf(".");
        printf("Customer ID: %d", ID);
        printf("\n");
        printf("Customer Name: %s", N);
        printf("\n");
        printf("Units Consumed: %d", Units);
        printf("\n");
        printf("Amount Charges @ Rs20.10 per unit: %d", Amount);
        printf("\n");
        printf("Surcharge Amount: %d", Surcharge);
        printf("\n");
        printf("Net Amount Paid by the Customer: %d", Net);

    } // end else if

    else if(Units >= 300 && Units < 500)
    { // start if

        Amount = Units * 27.1;

        if(Amount > 18000)
        { // start if

            Surcharge = Amount * 0.15;

        } // end if

        else
        { // start if 

            Surcharge = 0;

        }// end else

        Net = Amount + Surcharge;

        printf(".");
        printf("Customer ID: %d", ID);
        printf("\n");
        printf("Customer Name: %s", N);
        printf("\n");
        printf("Units Consumed: %d", Units);
        printf("\n");
        printf("Amount Charges @ Rs27.10 per unit: %d", Amount);
        printf("\n");
        printf("Surcharge Amount: %d", Surcharge);
        printf("\n");
        printf("Net Amount Paid by the Customer: %d", Net);

    } // end else if

    else if(Units >= 500)
    { // start if

        Amount = Units * 35.9;

        if(Amount > 18000)
        { // start if

            Surcharge = Amount * 0.15;

        } // end if

        else
        { // start if 

            Surcharge = 0;

        }// end else

        Net = Amount + Surcharge;

        printf(".");
        printf("Customer ID: %d", ID);
        printf("\n");
        printf("Customer Name: %s", N);
        printf("\n");
        printf("Units Consumed: %d", Units);
        printf("\n");
        printf("Amount Charges @ Rs35.90 per unit: %d", Amount);
        printf("\n");
        printf("Surcharge Amount: %d", Surcharge);
        printf("\n");
        printf("Net Amount Paid by the Customer: %d", Net);

    } // end else if

    else 
    { // start else

        printf("invalid input");

    } // end else

    return 0;

} // end main