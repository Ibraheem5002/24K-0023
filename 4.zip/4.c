#include <stdio.h>
    int main ()
{
    int Streak = 0;
    int Msg = 1;
    int Login;

    while (Msg == 1)
    {
        printf("did user login [1 for Yes, 0 for No]: ");
        scanf("%d", &Login);

        printf("did user sent a message [1 for Yes, 0 for No]: ");
        scanf("%d", &Msg);

        if (Msg == 1 && Login == 1)
        {
            Streak = Streak + 1;
        }
        
    }
    
    printf("streak lasted for (days): %d", Streak);

    return 0;
}