#include <stdio.h>
    int main ()
{
    int Loan;
    int Age;
    int Income;
    int Credit;

    printf("input your Age: ");
    scanf("%d", &Age);
    printf("input your Yearly Income: ");
    scanf("%d", &Income);
    printf("input your Credit Score: ");
    scanf("%d", &Credit);
    printf("how much Loan do you wish to take out: ");
    scanf("%d", &Loan);

    if (Age < 18)
    {
        printf("sorry, your Age do not meet the criteria [minimum 18 years old]");
    } // end if

    else if (Credit < 580)
    {
        printf("sorry, your Credit Score do not meet the criteria [minimum 580]");
    } // end else if

    else if (Loan > Income * 0.4)
    {
        printf("sorry, your Yearly Income do not meet the criteria [you cannot take out a loan for more than 40 percentage of your yearly income]");
    }

    else
    {
        printf("your Loan has been approved. Thankyou");
    }

    return 0;

}