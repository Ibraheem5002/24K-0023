#include <stdio.h>
    int main ()
{
    int Num;
    int Prime = 0;
    int i = 0;
    int Div = 2;

    printf("input your number: ");
    scanf("%d", &Num);

    while (Div < Num)
    {
        if (Num % Div == 0)
        {
            Prime = Prime + 1;
        }
        Div = Div + 1;    
    }
    
    if (Prime == 0)
    {
        printf("%d", Num);
        printf("is a prime");
    }
    else
    {
        printf("%d", Num);
        printf("is a not a prime");
    }

    return 0;
}