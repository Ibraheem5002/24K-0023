#include <stdio.h>
    int main()
{ // start main

    char Type1;
    char Type2;
    float Temp1;
    float Temp;

    printf("input your desired units [C for Celsius, F for Fahrenhite, K for Kelvin] \n");
    scanf("%c", &Type1);
    printf("input your measurement: ");
    scanf("%f", &Temp1);
    printf("input your desired units for conversion [C for Celsius, F for Fahrenhite, K for Kelvin] \n");
    scanf(" %c", &Type2);

    if (Type1 == 'C' && Type2 == 'F')
    { // start if

        Temp = Temp1 * 1.8 +32;
        printf("your new temp is: %f", Temp);

    } // end if

    else if (Type1 == 'C' && Type2 == 'K')
    { // start else if

        Temp = Temp1 +273.15;
        printf("your new temp is: %f", Temp);

    } // end else if

    else if (Type1 == 'C' && Type2 == 'C')
    { // start else if

        printf("you are stupid");

    } // end else if

    else if (Type1 == 'F' && Type2 == 'C')
    { // start else if

        Temp = (Temp1 - 32) * 0.556;
        printf("your new temp is: %f", Temp);

    } // end else if

    else if (Type1 == 'F' && Type2 == 'K')
    { // start else if

        Temp = (Temp1 - 32) * 0.556 + 273.15;
        printf("your new temp is: %f", Temp);

    } // end else if

    else if (Type1 == 'F' && Type2 == 'F')
    { // start else if

        printf("you are stupid");

    } // end else if

    else if (Type1 == 'K' && Type2 == 'C')
    { // start else if

        Temp = Temp1 - 273.15;
        printf("your new temp is: %f", Temp);

    } // end else if

    else if (Type1 == 'K' && Type2 == 'F')
    { // start else if

        Temp = (Temp1 - 273.15) * 1.8 + 32;
        printf("your new temp is: %f", Temp);

    } // end else if

     else if (Type1 == 'K' && Type2 == 'K')
    { // start else if

        printf("you are stupid");

    } // end else if

    else
    { // start else

        printf("invalid input");

    } // end else

    printf("Thank you for using our AI-powered temperature converter.");

    return 0;
}
