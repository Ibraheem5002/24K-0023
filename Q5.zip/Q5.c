#include<stdio.h>
    int main()
{

    //declairing the variables

    float Principle;
    float Rate;
    float Time;
    float Intrest;

    // inputing the data

    printf("enter your Principle. MUST BE BETWEEN 100 TO 1,000,000: \n");
    scanf("%f",  &Principle); 
    printf("enter your Rate, in %. MUST BE BETWEEN 5 TO 10: \n");
    scanf("%f", &Rate);
    printf("enter your Time period, in years. MUST BE BETWEEN 1 TO 10: \n");
    scanf("%f", &Time);

    // processing

    Intrest = (Principle * Rate * Time) / 100;

    //outputing the result
    
    printf("your simple Intrest is: %f\n", Intrest);

    return 0;

}