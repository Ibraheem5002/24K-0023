#include <stdio.h>
int main()
{ // start main
    int Num;
    
    printf("input you number: ");
    scanf("%d", &Num);

    if (Num%2 == 0)
    { // start if
        printf("This number is even");
    } // end if
    else 
    { // start else
        printf("This number is odd");
    } // end else

    return 0;

} // end main