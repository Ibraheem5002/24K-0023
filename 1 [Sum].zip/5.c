#include <stdio.h>
    int main ()
{
    int Sum = 0;
    int size;

    printf("input the size of your array: ");
    scanf("%d", &size);

    int Array[size];

    printf("input your data [integers only]: \n");
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &Array[i]);
    }

    for (int i = 0; i < size; i++)
    {
        Sum = Sum + Array[i];
    }

    printf("Sum: %d", Sum);
    return 0;
}