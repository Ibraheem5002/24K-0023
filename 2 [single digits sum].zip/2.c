#include <stdio.h>
    int main ()
{
    int Num;
    int Ans;
    int Sum = 0;
    int Digit;
    int Remain;

    printf("input your number: ");
    scanf("%d", &Num);

    Remain = Num;

    while (Remain != 0)
    {
        Digit = Remain % 10;
        Remain = Remain / 10;
        Sum = Sum + Digit;
    }
    
    Ans = Sum;

    printf("your answer: %d", Ans);

    return 0;

}