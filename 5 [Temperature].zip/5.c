#include  <stdio.h>
    int main ()
{
    int Temp[7];
    float Avg = 0.0;
    int Day = 0;
    int Sum = 0;

    for (int i = 0; i < 7; i++)
    {
        Day = i + 1;
        printf("input the temp [in C] of day %d: ", Day);
        scanf("%d", &Temp[i]);
        Sum = Sum + Temp[i];
    }

    for (int i = 0; i < 7; i++)
    {
        Day = i + 1;
        if (Temp[i] > 40 || Temp[i] < 0)
        {
            printf("extreme temperature on day: %d\n", Day);
        }
    }
    
    Avg = Sum / 7;
    printf("average of 7 day temperatures: %f", Avg);
    
    return 0;
}